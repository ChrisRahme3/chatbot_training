# Analytics Samples

The Google Analytics API lets you collect, configure, and analyze your data to reach the right audience.

[Getting Started](https://developers.google.com/analytics/)

## Running the sample

`node analytics.js`