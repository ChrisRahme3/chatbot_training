Closing as this does not appear to be an issue. If you are convinced that this is really a bug, please feel free to re-open the issue and add more information such as:

* Expected behavior
* Actual behavior
* Code samples
* Version numbers
* References docs or other links

Or, consider opening a Pull Request.

__Otherwise, support questions are handled on [Stack Overflow][stackoverflow].__ [![Ask a question on Stackoverflow][overflowimg]][stackoverflow]

[overflowimg]: https://googledrive.com/host/0ByfSjdPVs9MZbkhjeUhMYzRTeEE/stackoveflow-tag.png
[stackoverflow]: http://stackoverflow.com/questions/tagged/google-api-nodejs-client
